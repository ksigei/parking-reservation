from django.contrib import admin
from .models import ParkingSpot

admin.site.register(ParkingSpot)
